# first assignment

## description

the assignment is slicing the design into usable web page. hopefully student can duplicate the design as close as possible.

## design

[FIGMA](https://www.figma.com/file/HrpywqiFvbgrbYVcEPAYZj/Individual-Assignment-Batch-8?type=design&mode=design&t=4WdciSciltKnCJwT-1)

## Tools

for this assignment I use html and tailwindcss. the tailwind itself I am using both cdn and cli because of technical issue that I encounter.

## Note

if something not going properly, you probably need to `npm install`

```sh
npm install
```
